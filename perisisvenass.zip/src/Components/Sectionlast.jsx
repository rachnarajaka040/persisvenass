import React from 'react'
import '../App.css'
function Sectionlast() {
  return (
    <div>
        <div className="card-body div1" >

<u ><h5 style={{ color: "red", fontWeight: "600px", fontSize: "1.25em" }}>We have a coordination test for humanity. </h5></u> <br />
<p className="card-text pclass ">If we have every individual with a self-interest approach we go into a terrible situation. The more we convert to love for others the better chance we have to pass the test. </p>
<p className="p-3 mb-2 bg-body-tertiary pclass" style={{ borderLeft: "4px solid red", fontSize: "1.2em", fontStyle: "italic", lineHeight: "1.5" }}>“If only we could make love what people optimize for over wealth. We can help society at large realize that is the true way to win the game of life”<a href="https://jackjay.io/" style={{ color: "black" }}>-Jack Jay</a></p>
<p className="card-text pclass">If we can change whats cool, then love can rule.</p> <br></br>
<p className="card-text pclass">It wasn't until our culture defined cigarettes as bad that we quit them. They are just as addicting. They become negative status symbols. Hopefully showing the power status has on human behavior. If you thought sex/mating runs the world just wait till you realize that status is above even that.  </p> 
<p className="card-text pclass">If you are moved, then let’s move mountains.</p> <br></br>
<p className="card-text pclass">Schedule a call <a href="https://www.calendar.com/not-found/">HERE</a></p>

</div>
    </div>
  )
}

export default Sectionlast